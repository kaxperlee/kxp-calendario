@extends('layouts.main')

@section('sidebar')
<x-sb-calendario />
@endsection

@section('main')
<x-cab1 texto="Eventos" />
<x-cab2 texto="Listado de eventos ({{$ano}})" />
<table class="table">
    <tr>
        <th>Evento</th>
        <th>Tipo</th>
        <th>Fecha</th>
        <th>Columna</th>
    </tr>

    @foreach ($eventos as $evento)
    <tr>
        <td><a href="{{route('evento.show',$evento)}}">{{$evento->nombre}}</a></td>
        <td>
            {{$evento->descripcion}}
            @if ($evento->Evento === 'c')
                ({{$evento->Tipo}})
            @elseif ($evento->Evento === 'l')
                ({{$evento->Tipo}})
            @endif
        </td>
        <td>{{$evento->fecha}}</td>
        <td>{{$evento->columna}}</td>
    </tr>
    @endforeach
</table>
@endsection
