@extends('layouts.main')

@section('sidebar')
<x-sb-calendario />
@endsection

@section('main')
<x-cab1 texto="Empresas" />
<x-cab2 texto="Empresa: {{$evento->nombre}}" />
<div class="px-3">
    <div class="container-fluid">
    <div class="row">
        <div class="col-12 my-2">
            <label for="nombre">Fiesta:</label><br>
            <input  class="form-control" type="text" name="nombre" value="{{$evento->nombre}}" readonly>
        </div>
        <div class="col-3 my-2">
            <label for="Evento">Evento:</label><br>
            <input  class="form-control" type="text" name="Evento" value="{{$evento->Evento}}" readonly>
        </div>
        <div class="col-4 my-2">
            <label for="Tipo">Tipo: </label><br>
            <input  class="form-control" type="text" name="Tipo" value="{{$evento->Tipo}}" readonly>
        </div>
        <div class="col-3 my-2">
            <label for="fecha">Fecha:</label><br>
            <input  class="form-control" type="text" name="fecha" value="{{$evento->fecha}}" readonly>
        </div>
        <div class="col-2 my-2">
            <label for="columna">Columna:</label><br>
            <input  class="form-control" type="text" name="columna" value="{{$evento->columna}}" readonly>
        </div>
        <div class="col my-2">
            <a type="button" href="{{route('evento.edit', $evento)}}" class="btn btn-primary me-2"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
        </div>
    </div>
    </div>
</div>
@endsection
