@extends('layouts.main')

@section('sidebar')
<x-sb-calendario />
@endsection

@section('main')
<x-cab1 texto="Eventos" />
<x-cab2 texto="Alta evento" />
<div class="px-3">
<form method="POST" action="{{route('evento.store')}}">
    @csrf
    <div class="container-fluid">
    <div class="row">
        <div class="col-12 my-2">
            <label for="nombre">Nombre:</label><br>
            <input  class="form-control" type="text" name="nombre" value="">
        </div>
        <div class="col-3 my-2">
            <label for="Evento">Fiesta:</label><br>
            <select name="Evento" class="form-select" aria-label="Default select example">
                <option selected>Selecciona uno</option>
                <option value="n">Nacional</option>
                <option value="c">Comunidad</option>
                <option value="l">Local</option>
              </select>
        </div>
        <div class="col-4 my-2">
            <label for="Tipo">Tipo:</label><br>
            <input  class="form-control" type="text" name="Tipo" value="">
        </div>

        <div class="col-3 my-2">
            <label for="fecha">Fecha: </label><br>
            <input class="form-control" type="date" name="fecha" value="">
        </div>
        <div class="col-2 my-2">
            <label for="columna">Columna:</label><br>
            <select name="columna" class="form-select" aria-label="Default select example">
                <option selected></option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
              </select>
        </div>
        <div class="col my-2">
            <button class="btn btn-primary" type="submit">Guardar</button>
        </div>
    </div>
    </div>
</form>
</div>
@endsection
