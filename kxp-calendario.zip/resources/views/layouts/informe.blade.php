<div class="container-fluid px-0">
    <table class="head1" style='border: 0px solid #ccc; border-collapse: collapse;' width=100%>
        <tr vertical-align="top">
            <td  style='border: 0px solid #444; margin-bottom:auto'><img src="{{asset('img/logo.png')}}" class="rounded float-start" width="250" alt="Grupo Asesor Ros"></td>
            <td  style='border: 0px solid #444;' align="right">Calendario laboral 2023<br></br></td>
        </tr>
    </table>
    <table width="100%">
        <tr>
            <td align="left" width="15%" style='border: 0px solid #444;'><p>Empresa: </p></td>
            <td align="left" width="50%" style='border: 0px solid #444;'><p>GRUPO ASESOR ROS S.L.P </p></td>
            <td align="left" width="15%" style='border: 0px solid #444;'><p>Localidad: </p></td>
            <td align="left" width="20%" style='border: 0px solid #444;'><p>ELCHE</p></td>
        </tr>
        <tr>
            <td  align="left" style='border: 0px solid #444;'><p>Domicilio: </p></td>
            <td align="left" colspan="3" style='border: 0px solid #444;'><p>PLAZA PALACIO nº 1 ENT </p></td>
        </tr>
        <tr>
            <td align="left" colspan="1" style='border: 0px solid #444;'><p>Actividad: </p></td>
            <td align="left" colspan="3" style='border: 0px solid #444;'><p>ASESORIA EMPRESA </p></td>
        </tr>
        <tr>
            <td align="left" colspan="1" style='border: 0px solid #444;'><p>Convenio: </p></td>
            <td align="left" colspan="3" style='border: 0px solid #444;'><p>GRUPO ASESOR ROS S.L.P.</p></td>
        </tr>
    </table>
  </br>


</div>



