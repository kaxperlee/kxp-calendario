<p class="h5 text-dark pb-2 ps-1" style='font-family: roboto;font-weight: 600;'>
    {{$texto}}
</p>
