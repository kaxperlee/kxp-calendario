<p class="h5 text-primary py-2 mb-2" style='border-bottom: 1px solid #ccc; margin-bottom: 0px;font-weight: 600;'>{{$texto}}</p>


    
