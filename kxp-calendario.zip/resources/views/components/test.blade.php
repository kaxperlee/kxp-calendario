<div class="container px-0">
    <div class="d-flex bg-primary text-white"  >
        <div class="text-center py-2 mx-auto">
            <h5 class="text-uppercase my-0">prueba: {{$test}} </h5>
        </div>
    </div>
</div>
