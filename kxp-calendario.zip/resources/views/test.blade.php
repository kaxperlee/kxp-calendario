@extends('layouts.main')
@section('sidebar')
@endsection

@section('main')
<x-test />
@endsection
